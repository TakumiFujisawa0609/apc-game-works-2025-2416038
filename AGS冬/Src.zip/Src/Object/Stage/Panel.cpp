#include "Panel.h"

Panel::Panel(void)
{
}

Panel::~Panel(void)
{
}

//void Panel::Update(void)
//{
//	StageBase::Update();
//}
//
//void Panel::Draw(void)
//{
//	StageBase::Draw();
//}
//
//void Panel::Release(void)
//{
//	StageBase::Release();
//}
